# Shit Patrol: an automated playlist

Years ago, I was involved in college radio. Every week, we would get hundreds of new albums from bands & promoters that wanted us to put their music on air.

We listened to every single CD we received. At least a few tracks, at least 30 seconds per. We called this Shit Patrol, and it was as mind expanding as it was brain melting.

The struggle to discover new music is real. Spotify algorithms help, but by design they will not push you out of your comfort zone. Proactively seeking out new music is a constant labor, which is only intermittently joyous.

You can’t do Shit Patrol for every new album that comes out. But, it turns out you can do it for every band that plays in New York City on any given week.

And then, when you hear something you love, you can have the immediate gratification of getting to see that band live!

Uses AWS Lambda to trigger daily execution.

Playlist link :) https://open.spotify.com/playlist/0cchFuZ8BigXzce2s9rHQH?si=f9912aa5550e4a35
